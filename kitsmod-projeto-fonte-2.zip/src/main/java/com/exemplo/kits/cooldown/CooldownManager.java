package com.exemplo.kits.cooldown;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Controla o cooldown de resgate de kits (5 dias por kit, por jogador).
 * Persiste em config/kitsmod/cooldowns.json.
 */
public class CooldownManager {

    public static final long KIT_COOLDOWN_MS = 5L * 24 * 60 * 60 * 1000; // 5 dias

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final java.lang.reflect.Type DATA_TYPE =
            new TypeToken<Map<String, Map<String, Long>>>() {}.getType();

    private final Path filePath;
    // UUID (string) -> (kit -> timestamp do último resgate)
    private final Map<String, Map<String, Long>> data = new ConcurrentHashMap<>();

    public CooldownManager(Path configDir) {
        this.filePath = configDir.resolve("cooldowns.json");
        load();
    }

    public synchronized void load() {
        data.clear();
        if (!Files.exists(filePath)) {
            return;
        }
        try (FileReader reader = new FileReader(filePath.toFile())) {
            Map<String, Map<String, Long>> loaded = GSON.fromJson(reader, DATA_TYPE);
            if (loaded != null) {
                data.putAll(loaded);
            }
        } catch (IOException e) {
            System.err.println("[kitsmod] Falha ao carregar cooldowns.json: " + e.getMessage());
        }
    }

    public synchronized void save() {
        try {
            Files.createDirectories(filePath.getParent());
            try (FileWriter writer = new FileWriter(filePath.toFile())) {
                GSON.toJson(data, DATA_TYPE, writer);
            }
        } catch (IOException e) {
            System.err.println("[kitsmod] Falha ao salvar cooldowns.json: " + e.getMessage());
        }
    }

    /**
     * @return milissegundos restantes de cooldown (0 se já pode resgatar)
     */
    public synchronized long getRemainingCooldown(UUID uuid, String kit) {
        Map<String, Long> playerData = data.get(uuid.toString());
        if (playerData == null) return 0;

        Long lastUsed = playerData.get(kit.toLowerCase());
        if (lastUsed == null) return 0;

        long elapsed = System.currentTimeMillis() - lastUsed;
        long remaining = KIT_COOLDOWN_MS - elapsed;
        return Math.max(remaining, 0);
    }

    public synchronized void setUsedNow(UUID uuid, String kit) {
        Map<String, Long> playerData = data.computeIfAbsent(uuid.toString(), k -> new ConcurrentHashMap<>());
        playerData.put(kit.toLowerCase(), System.currentTimeMillis());
        save();
    }
}
