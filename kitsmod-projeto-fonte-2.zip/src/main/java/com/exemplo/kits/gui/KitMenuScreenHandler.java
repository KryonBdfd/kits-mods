package com.exemplo.kits.gui;

import com.exemplo.kits.kit.KitService;
import com.exemplo.kits.kit.KitType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.Inventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

/**
 * Menu do comando /kits: um baú de 1 linha (9 slots) mostrando os ícones
 * de cada kit. Clicar em um ícone resgata aquele kit imediatamente
 * (chamando a mesma lógica do comando /kit).
 *
 * Os slots são "travados" (LockedSlot) para que o jogador não consiga
 * retirar/mover os itens de vitrine; o clique é interceptado em
 * onSlotClick() e usado apenas como gatilho.
 */
public class KitMenuScreenHandler extends ScreenHandler {

    public static final int MENU_SIZE = 9;

    // slot -> kit representado naquele slot
    private static final KitType[] SLOT_KITS = new KitType[MENU_SIZE];

    static {
        SLOT_KITS[0] = KitType.VIP;
        SLOT_KITS[1] = KitType.VIP_PLUS;
        SLOT_KITS[2] = KitType.PRO;
        SLOT_KITS[3] = KitType.SSLAYERS;
        SLOT_KITS[4] = KitType.SSLAYERS_PLUS;
        SLOT_KITS[6] = KitType.ADMIN; // deixa um espaço (slot 5) vazio para separar visualmente
    }

    private final Inventory menuInventory;

    public KitMenuScreenHandler(int syncId, PlayerInventory playerInventory, ServerPlayerEntity viewer) {
        super(ScreenHandlerType.GENERIC_9X1, syncId);

        this.menuInventory = new SimpleInventory(MENU_SIZE);
        populateMenu(viewer);

        // slots do menu (linha única, topo)
        for (int col = 0; col < MENU_SIZE; col++) {
            this.addSlot(new LockedSlot(menuInventory, col, 8 + col * 18, 18));
        }

        // inventário do jogador (3 linhas)
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                this.addSlot(new Slot(playerInventory, col + row * 9 + 9, 8 + col * 18, 51 + row * 18));
            }
        }
        // hotbar do jogador
        for (int col = 0; col < 9; col++) {
            this.addSlot(new Slot(playerInventory, col, 8 + col * 18, 109));
        }
    }

    private void populateMenu(ServerPlayerEntity viewer) {
        set(0, Items.YELLOW_DYE, KitType.VIP);
        set(1, Items.GREEN_DYE, KitType.VIP_PLUS);
        set(2, Items.LIGHT_BLUE_DYE, KitType.PRO);
        set(3, Items.PINK_DYE, KitType.SSLAYERS);
        set(4, Items.PURPLE_DYE, KitType.SSLAYERS_PLUS);

        // o kit Admin só aparece no menu para jogadores OP nível 4
        if (viewer.hasPermissionLevel(4)) {
            set(6, Items.COMMAND_BLOCK, KitType.ADMIN);
        }
    }

    private void set(int slot, Item item, KitType type) {
        ItemStack stack = new ItemStack(item);
        stack.set(net.minecraft.component.DataComponentTypes.CUSTOM_NAME, type.getDisplayText());
        menuInventory.setStack(slot, stack);
    }

    @Override
    public boolean canUse(PlayerEntity player) {
        return true;
    }

    @Override
    public void onSlotClick(int slotIndex, int button, SlotActionType actionType, PlayerEntity player) {
        // slots 0..MENU_SIZE-1 pertencem ao menu de kits
        if (slotIndex >= 0 && slotIndex < MENU_SIZE) {
            KitType type = SLOT_KITS[slotIndex];
            if (type != null && player instanceof ServerPlayerEntity serverPlayer) {
                KitService.redeem(serverPlayer, type);
            }
            // não chama super: impede qualquer movimentação real do item de vitrine
            return;
        }

        // clique fora do menu (inventário do jogador) funciona normalmente,
        // mas nunca deixa o jogador "puxar" o item de vitrine para o inventário
        super.onSlotClick(slotIndex, button, actionType, player);
    }

    @Override
    public ItemStack quickMove(PlayerEntity player, int index) {
        // desabilita shift-click completamente para este menu
        return ItemStack.EMPTY;
    }
}
