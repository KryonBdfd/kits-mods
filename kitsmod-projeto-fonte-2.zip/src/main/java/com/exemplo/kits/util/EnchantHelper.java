package com.exemplo.kits.util;

import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.component.type.UnbreakableComponent;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.MinecraftServer;

/**
 * Utilitário para aplicar encantamentos (normais e "armazenados", como em livros)
 * usando o sistema de componentes de dados do Minecraft 1.21.
 */
public final class EnchantHelper {

    private EnchantHelper() {
    }

    /**
     * Aplica um encantamento normal (equipável) em um item.
     */
    public static void enchant(MinecraftServer server, ItemStack stack, RegistryKey<Enchantment> enchantmentKey, int level) {
        RegistryEntry<Enchantment> entry = resolve(server, enchantmentKey);
        if (entry == null) return;

        ItemEnchantmentsComponent current = stack.getOrDefault(DataComponentTypes.ENCHANTMENTS, ItemEnchantmentsComponent.DEFAULT);
        ItemEnchantmentsComponent.Builder builder = new ItemEnchantmentsComponent.Builder(current);
        builder.add(entry, level);
        stack.set(DataComponentTypes.ENCHANTMENTS, builder.build());
    }

    /**
     * Aplica um encantamento "armazenado" (usado em livros encantados).
     */
    public static void storeEnchant(MinecraftServer server, ItemStack stack, RegistryKey<Enchantment> enchantmentKey, int level) {
        RegistryEntry<Enchantment> entry = resolve(server, enchantmentKey);
        if (entry == null) return;

        ItemEnchantmentsComponent current = stack.getOrDefault(DataComponentTypes.STORED_ENCHANTMENTS, ItemEnchantmentsComponent.DEFAULT);
        ItemEnchantmentsComponent.Builder builder = new ItemEnchantmentsComponent.Builder(current);
        builder.add(entry, level);
        stack.set(DataComponentTypes.STORED_ENCHANTMENTS, builder.build());
    }

    /**
     * Marca o item como inquebrável (esconde ou não a tag no tooltip).
     */
    public static void unbreakable(ItemStack stack) {
        stack.set(DataComponentTypes.UNBREAKABLE, new UnbreakableComponent(true));
    }

    private static RegistryEntry<Enchantment> resolve(MinecraftServer server, RegistryKey<Enchantment> key) {
        return server.getRegistryManager()
                .get(RegistryKeys.ENCHANTMENT)
                .getEntry(key)
                .orElse(null);
    }
}
