package com.exemplo.kits.util;

/**
 * Converte strings de duração no formato "30d", "12h", "45m" para milissegundos.
 * Aceita apenas um sufixo por vez: m (minutos), h (horas), d (dias).
 */
public final class TimeParser {

    private TimeParser() {
    }

    public static final long MINUTE_MS = 60_000L;
    public static final long HOUR_MS = 60L * MINUTE_MS;
    public static final long DAY_MS = 24L * HOUR_MS;

    /**
     * @param input string tipo "30d", "12h", "45m"
     * @return duração em milissegundos, ou -1 se o formato for inválido
     */
    public static long parseToMillis(String input) {
        if (input == null || input.isEmpty()) {
            return -1;
        }
        input = input.trim().toLowerCase();
        char unit = input.charAt(input.length() - 1);
        String numberPart = input.substring(0, input.length() - 1);

        long amount;
        try {
            amount = Long.parseLong(numberPart);
        } catch (NumberFormatException e) {
            return -1;
        }

        if (amount <= 0) {
            return -1;
        }

        return switch (unit) {
            case 'm' -> amount * MINUTE_MS;
            case 'h' -> amount * HOUR_MS;
            case 'd' -> amount * DAY_MS;
            default -> -1;
        };
    }

    /**
     * Formata milissegundos restantes em um texto amigável tipo "2d 4h 10m".
     */
    public static String formatRemaining(long millis) {
        if (millis <= 0) {
            return "0m";
        }
        long days = millis / DAY_MS;
        millis %= DAY_MS;
        long hours = millis / HOUR_MS;
        millis %= HOUR_MS;
        long minutes = millis / MINUTE_MS;
        // arredonda pra cima se sobrar resto de segundos
        if (millis % MINUTE_MS > 0) {
            minutes += 1;
        }

        StringBuilder sb = new StringBuilder();
        if (days > 0) sb.append(days).append("d ");
        if (hours > 0) sb.append(hours).append("h ");
        if (minutes > 0 || sb.isEmpty()) sb.append(minutes).append("m");

        return sb.toString().trim();
    }
}
