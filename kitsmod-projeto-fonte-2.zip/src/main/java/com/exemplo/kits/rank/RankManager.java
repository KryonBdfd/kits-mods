package com.exemplo.kits.rank;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Gerencia os ranks temporários/permanentes de todos os jogadores.
 * Persiste tudo em config/kitsmod/ranks.json.
 * Um jogador pode ter vários ranks simultaneamente (ex: vip e pro ao mesmo tempo).
 */
public class RankManager {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final java.lang.reflect.Type DATA_TYPE =
            new TypeToken<Map<String, List<RankEntry>>>() {}.getType();

    private final Path filePath;
    // UUID (string) -> lista de ranks ativos
    private final Map<String, List<RankEntry>> data = new ConcurrentHashMap<>();

    public RankManager(Path configDir) {
        this.filePath = configDir.resolve("ranks.json");
        load();
    }

    public synchronized void load() {
        data.clear();
        if (!Files.exists(filePath)) {
            return;
        }
        try (FileReader reader = new FileReader(filePath.toFile())) {
            Map<String, List<RankEntry>> loaded = GSON.fromJson(reader, DATA_TYPE);
            if (loaded != null) {
                data.putAll(loaded);
            }
        } catch (IOException e) {
            System.err.println("[kitsmod] Falha ao carregar ranks.json: " + e.getMessage());
        }
    }

    public synchronized void save() {
        try {
            Files.createDirectories(filePath.getParent());
            try (FileWriter writer = new FileWriter(filePath.toFile())) {
                GSON.toJson(data, DATA_TYPE, writer);
            }
        } catch (IOException e) {
            System.err.println("[kitsmod] Falha ao salvar ranks.json: " + e.getMessage());
        }
    }

    /**
     * Adiciona (ou renova) um rank para o jogador.
     * @param durationMillis -1 para permanente
     */
    public synchronized void addRank(UUID uuid, String rank, long durationMillis) {
        String key = uuid.toString();
        List<RankEntry> list = data.computeIfAbsent(key, k -> new CopyOnWriteArrayList<>());

        long expiresAt = durationMillis < 0 ? -1 : System.currentTimeMillis() + durationMillis;

        // remove entrada anterior do mesmo rank (renovação) antes de adicionar a nova
        list.removeIf(entry -> entry.rank.equalsIgnoreCase(rank));
        list.add(new RankEntry(rank.toLowerCase(), expiresAt));

        save();
    }

    /**
     * Remove um rank específico do jogador.
     * @return true se o rank existia e foi removido
     */
    public synchronized boolean removeRank(UUID uuid, String rank) {
        List<RankEntry> list = data.get(uuid.toString());
        if (list == null) return false;

        boolean removed = list.removeIf(entry -> entry.rank.equalsIgnoreCase(rank));
        if (removed) {
            save();
        }
        return removed;
    }

    /**
     * @return true se o jogador possui o rank informado e ele ainda não expirou.
     */
    public synchronized boolean hasRank(UUID uuid, String rank) {
        List<RankEntry> list = data.get(uuid.toString());
        if (list == null) return false;
        return list.stream().anyMatch(e -> e.rank.equalsIgnoreCase(rank) && !e.isExpired());
    }

    public synchronized List<RankEntry> getRanks(UUID uuid) {
        return data.getOrDefault(uuid.toString(), List.of());
    }

    /**
     * Varre todos os ranks de todos os jogadores, remove os expirados
     * e notifica o jogador (se estiver online) que o rank acabou.
     * Deve ser chamado periodicamente (ex: a cada 20 ticks) pelo servidor.
     */
    public synchronized void tickExpirations(MinecraftServer server) {
        boolean changed = false;

        for (Map.Entry<String, List<RankEntry>> entry : data.entrySet()) {
            UUID uuid;
            try {
                uuid = UUID.fromString(entry.getKey());
            } catch (IllegalArgumentException ex) {
                continue;
            }

            List<RankEntry> ranks = entry.getValue();
            List<RankEntry> expired = ranks.stream().filter(RankEntry::isExpired).toList();

            if (!expired.isEmpty()) {
                ranks.removeAll(expired);
                changed = true;

                ServerPlayerEntity player = server.getPlayerManager().getPlayer(uuid);
                if (player != null) {
                    for (RankEntry exp : expired) {
                        player.sendMessage(Text.literal("§c[Kits] §7Seu rank §f" + exp.rank.toUpperCase()
                                + " §7expirou!"), false);
                    }
                }
            }
        }

        if (changed) {
            save();
        }
    }
}
