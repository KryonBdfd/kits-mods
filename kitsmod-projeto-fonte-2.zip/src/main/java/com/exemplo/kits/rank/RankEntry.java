package com.exemplo.kits.rank;

/**
 * Representa um rank ativo de um jogador, com o timestamp (epoch millis)
 * em que ele expira. Se expiresAt == -1, o rank é permanente.
 */
public class RankEntry {
    public String rank;
    public long expiresAt;

    public RankEntry() {
    }

    public RankEntry(String rank, long expiresAt) {
        this.rank = rank;
        this.expiresAt = expiresAt;
    }

    public boolean isPermanent() {
        return expiresAt < 0;
    }

    public boolean isExpired() {
        return !isPermanent() && System.currentTimeMillis() >= expiresAt;
    }
}
