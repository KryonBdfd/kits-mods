package com.exemplo.kits.command;

import com.exemplo.kits.kit.KitService;
import com.exemplo.kits.kit.KitType;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

public final class KitCommand {

    private KitCommand() {
    }

    private static final SuggestionProvider<ServerCommandSource> KIT_SUGGESTIONS = (ctx, builder) -> {
        for (KitType type : KitType.values()) {
            builder.suggest(type.getId());
        }
        return builder.buildFuture();
    };

    public static void register(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(literal("kit")
                .then(argument("nome", StringArgumentType.word())
                        .suggests(KIT_SUGGESTIONS)
                        .executes(ctx -> {
                            ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
                            String name = StringArgumentType.getString(ctx, "nome");
                            KitType type = KitType.byId(name);

                            if (type == null) {
                                ctx.getSource().sendError(Text.literal("Kit inválido! Use: vip, vipplus, pro, sslayers, sslayersplus, admin")
                                        .formatted(Formatting.RED));
                                return 0;
                            }

                            KitService.redeem(player, type);
                            return 1;
                        }))
                .executes(ctx -> {
                    ctx.getSource().sendError(Text.literal("Uso correto: /kit <nome>").formatted(Formatting.RED));
                    return 0;
                }));
    }
}
