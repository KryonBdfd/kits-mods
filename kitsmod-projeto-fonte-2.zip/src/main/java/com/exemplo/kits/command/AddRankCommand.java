package com.exemplo.kits.command;

import com.exemplo.kits.KitsMod;
import com.exemplo.kits.kit.KitType;
import com.exemplo.kits.util.TimeParser;
import com.mojang.authlib.GameProfile;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.command.argument.GameProfileArgumentType;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.Collection;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

public final class AddRankCommand {

    private AddRankCommand() {
    }

    public static void register(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(literal("addrank")
                .requires(source -> source.hasPermissionLevel(4)) // somente OP nível 4
                .then(argument("jogador", GameProfileArgumentType.gameProfile())
                        .then(argument("rank", StringArgumentType.word())
                                .then(argument("tempo", StringArgumentType.word())
                                        .executes(AddRankCommand::run)))));
    }

    private static int run(com.mojang.brigadier.context.CommandContext<ServerCommandSource> ctx) {
        Collection<GameProfile> profiles = GameProfileArgumentType.getProfileArgument(ctx, "jogador");
        String rankInput = StringArgumentType.getString(ctx, "rank");
        String tempoInput = StringArgumentType.getString(ctx, "tempo");

        KitType kitType = KitType.byId(rankInput.toLowerCase());
        if (kitType == null || kitType == KitType.ADMIN) {
            ctx.getSource().sendError(Text.literal(
                    "Rank inválido! Use: vip, vipplus, pro, sslayers, sslayersplus").formatted(Formatting.RED));
            return 0;
        }

        long durationMillis;
        if (tempoInput.equalsIgnoreCase("perm") || tempoInput.equalsIgnoreCase("permanente")) {
            durationMillis = -1;
        } else {
            durationMillis = TimeParser.parseToMillis(tempoInput);
            if (durationMillis <= 0) {
                ctx.getSource().sendError(Text.literal(
                        "Tempo inválido! Use por exemplo: 30d, 12h, 45m (ou 'perm' para permanente)").formatted(Formatting.RED));
                return 0;
            }
        }

        for (GameProfile profile : profiles) {
            KitsMod.RANKS.addRank(profile.getId(), kitType.getId(), durationMillis);

            String duracaoTexto = durationMillis < 0 ? "permanente" : TimeParser.formatRemaining(durationMillis);
            ctx.getSource().sendFeedback(() -> Text.literal("§a[Kits] §7Rank §f" + kitType.getDisplayName()
                    + " §7adicionado para §f" + profile.getName() + " §7por §f" + duracaoTexto), true);

            var server = ctx.getSource().getServer();
            var onlinePlayer = server.getPlayerManager().getPlayer(profile.getId());
            if (onlinePlayer != null) {
                onlinePlayer.sendMessage(Text.literal("§a[Kits] §7Você recebeu o rank §f"
                        + kitType.getDisplayName() + " §7por §f" + duracaoTexto + "§7!"), false);
            }
        }

        return 1;
    }
}
