package com.exemplo.kits.command;

import com.exemplo.kits.KitsMod;
import com.exemplo.kits.kit.KitType;
import com.mojang.authlib.GameProfile;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.command.argument.GameProfileArgumentType;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.Collection;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

public final class RemoveRankCommand {

    private RemoveRankCommand() {
    }

    public static void register(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(literal("removerank")
                .requires(source -> source.hasPermissionLevel(4)) // somente OP nível 4
                .then(argument("jogador", GameProfileArgumentType.gameProfile())
                        .then(argument("rank", StringArgumentType.word())
                                .executes(RemoveRankCommand::run))));
    }

    private static int run(com.mojang.brigadier.context.CommandContext<ServerCommandSource> ctx) {
        Collection<GameProfile> profiles = GameProfileArgumentType.getProfileArgument(ctx, "jogador");
        String rankInput = StringArgumentType.getString(ctx, "rank");

        KitType kitType = KitType.byId(rankInput.toLowerCase());
        if (kitType == null) {
            ctx.getSource().sendError(Text.literal(
                    "Rank inválido! Use: vip, vipplus, pro, sslayers, sslayersplus").formatted(Formatting.RED));
            return 0;
        }

        for (GameProfile profile : profiles) {
            boolean removed = KitsMod.RANKS.removeRank(profile.getId(), kitType.getId());

            if (removed) {
                ctx.getSource().sendFeedback(() -> Text.literal("§a[Kits] §7Rank §f" + kitType.getDisplayName()
                        + " §7removido de §f" + profile.getName()), true);

                var server = ctx.getSource().getServer();
                var onlinePlayer = server.getPlayerManager().getPlayer(profile.getId());
                if (onlinePlayer != null) {
                    onlinePlayer.sendMessage(Text.literal("§c[Kits] §7Seu rank §f"
                            + kitType.getDisplayName() + " §7foi removido por um administrador."), false);
                }
            } else {
                ctx.getSource().sendError(Text.literal(profile.getName() + " não possui o rank "
                        + kitType.getDisplayName()).formatted(Formatting.RED));
            }
        }

        return 1;
    }
}
