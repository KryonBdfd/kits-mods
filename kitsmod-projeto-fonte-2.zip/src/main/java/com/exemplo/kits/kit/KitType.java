package com.exemplo.kits.kit;

import net.minecraft.text.Text;

/**
 * Todos os kits disponíveis no mod.
 * O "id" é o nome usado em /kit <id> (sempre minúsculo, sem espaços).
 */
public enum KitType {
    VIP("vip", "§eVIP"),
    VIP_PLUS("vipplus", "§aVIP+"),
    PRO("pro", "§9PRO"),
    SSLAYERS("sslayers", "§dSSlayers"),
    SSLAYERS_PLUS("sslayersplus", "§5SSlayers+"),
    ADMIN("admin", "§4Admin");

    private final String id;
    private final String displayName;

    KitType(String id, String displayName) {
        this.id = id;
        this.displayName = displayName;
    }

    public String getId() {
        return id;
    }

    public String getDisplayName() {
        return displayName;
    }

    public Text getDisplayText() {
        return Text.literal(displayName);
    }

    public static KitType byId(String id) {
        if (id == null) return null;
        for (KitType type : values()) {
            if (type.id.equalsIgnoreCase(id)) {
                return type;
            }
        }
        return null;
    }
}
