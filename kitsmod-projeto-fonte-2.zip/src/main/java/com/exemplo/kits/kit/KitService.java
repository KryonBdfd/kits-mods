package com.exemplo.kits.kit;

import com.exemplo.kits.KitsMod;
import com.exemplo.kits.util.TimeParser;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

/**
 * Lógica central e compartilhada de resgate de kit: valida permissão
 * (rank do jogador), valida cooldown, entrega os itens e registra o uso.
 * Usada tanto pelo comando /kit quanto pelo clique no menu /kits.
 */
public final class KitService {

    private KitService() {
    }

    /**
     * Tenta resgatar um kit para o jogador. Envia mensagens de erro/sucesso
     * diretamente ao jogador.
     */
    public static void redeem(ServerPlayerEntity player, KitType type) {
        // Kit Admin exige OP nível 4, e não usa cooldown nem checagem de rank
        if (type == KitType.ADMIN) {
            if (!player.hasPermissionLevel(4)) {
                player.sendMessage(Text.literal("§cVocê não tem permissão para usar o kit Admin!"), false);
                return;
            }
            KitManager.giveKit(player, type);
            player.sendMessage(Text.literal("§a[Kits] §7Kit §f" + type.getDisplayName() + " §7entregue!"), false);
            return;
        }

        // Para os demais kits, o jogador precisa ter o rank correspondente ativo
        // (OPs nível 4 podem testar qualquer kit livremente)
        boolean isOp = player.hasPermissionLevel(4);
        if (!isOp && !KitsMod.RANKS.hasRank(player.getUuid(), type.getId())) {
            player.sendMessage(Text.literal("§c[Kits] §7Você não possui o rank §f" + type.getDisplayName()
                    + " §7para resgatar este kit!"), false);
            return;
        }

        long remaining = KitsMod.COOLDOWNS.getRemainingCooldown(player.getUuid(), type.getId());
        if (remaining > 0 && !isOp) {
            player.sendMessage(Text.literal("§c[Kits] §7Aguarde §f" + TimeParser.formatRemaining(remaining)
                    + " §7para resgatar o kit §f" + type.getDisplayName() + " §7novamente."), false);
            return;
        }

        KitManager.giveKit(player, type);
        KitsMod.COOLDOWNS.setUsedNow(player.getUuid(), type.getId());
        player.sendMessage(Text.literal("§a[Kits] §7Kit §f" + type.getDisplayName() + " §7entregue com sucesso!"), false);
    }
}
