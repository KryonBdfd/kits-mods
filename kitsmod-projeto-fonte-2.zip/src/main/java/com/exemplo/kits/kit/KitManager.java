package com.exemplo.kits.kit;

import com.exemplo.kits.util.EnchantHelper;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ContainerComponent;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.ArrayList;
import java.util.List;

/**
 * Monta e entrega os itens de cada kit.
 * Os níveis de encantamento seguem a progressão pedida:
 * VIP (nível I) -> VIP+ (nível II) -> PRO (nível III) -> SSlayers (nível IV) -> SSlayers+ (dobro do SSlayers)
 */
public class KitManager {

    public static void giveKit(ServerPlayerEntity player, KitType type) {
        MinecraftServer server = player.getServer();
        List<ItemStack> items = new ArrayList<>();

        switch (type) {
            case VIP -> buildVip(server, items);
            case VIP_PLUS -> buildVipPlus(server, items);
            case PRO -> buildPro(server, items);
            case SSLAYERS -> buildSSlayers(server, items, 1);
            case SSLAYERS_PLUS -> buildSSlayers(server, items, 2); // dobro dos itens/quantidades
            case ADMIN -> buildAdmin(server, items);
        }

        for (ItemStack stack : items) {
            giveOrDrop(player, stack);
        }
    }

    private static void giveOrDrop(ServerPlayerEntity player, ItemStack stack) {
        if (!player.getInventory().insertStack(stack.copy())) {
            player.dropItem(stack, false);
        }
    }

    // ---------------------------------------------------------------
    // VIP: full diamante Proteção I, espada diamante, ferramentas diamante
    // Eficiência I, encantamentos nível I, 2 livros Remendo, 1 livro
    // Inquebrável III, comida
    // ---------------------------------------------------------------
    private static void buildVip(MinecraftServer server, List<ItemStack> out) {
        addArmorSet(server, out, Items.DIAMOND_HELMET, Items.DIAMOND_CHESTPLATE,
                Items.DIAMOND_LEGGINGS, Items.DIAMOND_BOOTS, Enchantments.PROTECTION, 1);

        ItemStack sword = new ItemStack(Items.DIAMOND_SWORD);
        EnchantHelper.enchant(server, sword, Enchantments.SHARPNESS, 1);
        out.add(sword);

        addToolSet(server, out, Items.DIAMOND_PICKAXE, Items.DIAMOND_AXE,
                Items.DIAMOND_SHOVEL, Items.DIAMOND_HOE, Enchantments.EFFICIENCY, 1);

        out.add(enchantedBook(server, Enchantments.MENDING, 1));
        out.add(enchantedBook(server, Enchantments.MENDING, 1));
        out.add(enchantedBook(server, Enchantments.UNBREAKING, 3));

        addFood(out, 16);
    }

    // ---------------------------------------------------------------
    // VIP+: full netherita Proteção II, ferramentas nível II, livros encantados
    // ---------------------------------------------------------------
    private static void buildVipPlus(MinecraftServer server, List<ItemStack> out) {
        addArmorSet(server, out, Items.NETHERITE_HELMET, Items.NETHERITE_CHESTPLATE,
                Items.NETHERITE_LEGGINGS, Items.NETHERITE_BOOTS, Enchantments.PROTECTION, 2);

        ItemStack sword = new ItemStack(Items.NETHERITE_SWORD);
        EnchantHelper.enchant(server, sword, Enchantments.SHARPNESS, 2);
        EnchantHelper.enchant(server, sword, Enchantments.UNBREAKING, 2);
        out.add(sword);

        addToolSet(server, out, Items.NETHERITE_PICKAXE, Items.NETHERITE_AXE,
                Items.NETHERITE_SHOVEL, Items.NETHERITE_HOE, Enchantments.EFFICIENCY, 2);

        out.add(enchantedBook(server, Enchantments.MENDING, 1));
        out.add(enchantedBook(server, Enchantments.UNBREAKING, 3));
        out.add(enchantedBook(server, Enchantments.FIRE_PROTECTION, 2));

        addFood(out, 32);
    }

    // ---------------------------------------------------------------
    // PRO: full netherita nível III, mace sem encantamento, elytra,
    // beacon, 1 shulker com minérios, livros encantados
    // ---------------------------------------------------------------
    private static void buildPro(MinecraftServer server, List<ItemStack> out) {
        addArmorSet(server, out, Items.NETHERITE_HELMET, Items.NETHERITE_CHESTPLATE,
                Items.NETHERITE_LEGGINGS, Items.NETHERITE_BOOTS, Enchantments.PROTECTION, 3);

        ItemStack sword = new ItemStack(Items.NETHERITE_SWORD);
        EnchantHelper.enchant(server, sword, Enchantments.SHARPNESS, 3);
        EnchantHelper.enchant(server, sword, Enchantments.UNBREAKING, 3);
        EnchantHelper.enchant(server, sword, Enchantments.MENDING, 1);
        out.add(sword);

        addToolSet(server, out, Items.NETHERITE_PICKAXE, Items.NETHERITE_AXE,
                Items.NETHERITE_SHOVEL, Items.NETHERITE_HOE, Enchantments.EFFICIENCY, 3);

        out.add(new ItemStack(Items.MACE)); // sem encantamento, como pedido
        out.add(new ItemStack(Items.ELYTRA));
        out.add(new ItemStack(Items.BEACON));

        out.add(shulkerWith(oresList()));

        out.add(enchantedBook(server, Enchantments.MENDING, 1));
        out.add(enchantedBook(server, Enchantments.UNBREAKING, 3));
        out.add(enchantedBook(server, Enchantments.PROTECTION, 4));
        out.add(enchantedBook(server, Enchantments.SHARPNESS, 5));

        addFood(out, 32);
    }

    // ---------------------------------------------------------------
    // SSlayers: full netherita nível IV, mace forte, elytra, 1 shulker
    // com minérios, 1 shulker cheia de livros encantados.
    // multiplier = 1 (SSlayers) ou 2 (SSlayers+, itens/quantidades em dobro)
    // ---------------------------------------------------------------
    private static void buildSSlayers(MinecraftServer server, List<ItemStack> out, int multiplier) {
        addArmorSet(server, out, Items.NETHERITE_HELMET, Items.NETHERITE_CHESTPLATE,
                Items.NETHERITE_LEGGINGS, Items.NETHERITE_BOOTS, Enchantments.PROTECTION, 4);

        for (int i = 0; i < multiplier; i++) {
            ItemStack sword = new ItemStack(Items.NETHERITE_SWORD);
            EnchantHelper.enchant(server, sword, Enchantments.SHARPNESS, 5);
            EnchantHelper.enchant(server, sword, Enchantments.UNBREAKING, 3);
            EnchantHelper.enchant(server, sword, Enchantments.MENDING, 1);
            EnchantHelper.enchant(server, sword, Enchantments.FIRE_ASPECT, 2);
            EnchantHelper.enchant(server, sword, Enchantments.LOOTING, 3);
            out.add(sword);
        }

        addToolSet(server, out, Items.NETHERITE_PICKAXE, Items.NETHERITE_AXE,
                Items.NETHERITE_SHOVEL, Items.NETHERITE_HOE, Enchantments.EFFICIENCY, 5);

        for (int i = 0; i < multiplier; i++) {
            ItemStack mace = new ItemStack(Items.MACE);
            EnchantHelper.enchant(server, mace, Enchantments.DENSITY, 5);
            EnchantHelper.enchant(server, mace, Enchantments.UNBREAKING, 3);
            EnchantHelper.enchant(server, mace, Enchantments.MENDING, 1);
            out.add(mace);

            out.add(new ItemStack(Items.ELYTRA));
        }

        // shulker com minérios (dobra a quantidade dos minérios se for SSlayers+)
        out.add(shulkerWith(scaleStacks(oresList(), multiplier)));

        // shulker cheia de livros encantados
        List<ItemStack> books = new ArrayList<>();
        books.add(enchantedBook(server, Enchantments.PROTECTION, 4));
        books.add(enchantedBook(server, Enchantments.SHARPNESS, 5));
        books.add(enchantedBook(server, Enchantments.EFFICIENCY, 5));
        books.add(enchantedBook(server, Enchantments.UNBREAKING, 3));
        books.add(enchantedBook(server, Enchantments.MENDING, 1));
        books.add(enchantedBook(server, Enchantments.FIRE_ASPECT, 2));
        books.add(enchantedBook(server, Enchantments.LOOTING, 3));
        books.add(enchantedBook(server, Enchantments.FEATHER_FALLING, 4));
        books.add(enchantedBook(server, Enchantments.RESPIRATION, 3));
        books.add(enchantedBook(server, Enchantments.DENSITY, 5));
        out.add(shulkerWith(scaleStacks(books, multiplier)));

        addFood(out, 32 * multiplier);
    }

    // ---------------------------------------------------------------
    // Admin: os melhores itens possíveis do jogo (apenas via OP)
    // ---------------------------------------------------------------
    private static void buildAdmin(MinecraftServer server, List<ItemStack> out) {
        addArmorSet(server, out, Items.NETHERITE_HELMET, Items.NETHERITE_CHESTPLATE,
                Items.NETHERITE_LEGGINGS, Items.NETHERITE_BOOTS, Enchantments.PROTECTION, 4);

        for (ItemStack piece : out) {
            EnchantHelper.enchant(server, piece, Enchantments.UNBREAKING, 3);
            EnchantHelper.enchant(server, piece, Enchantments.MENDING, 1);
            EnchantHelper.unbreakable(piece);
        }

        ItemStack sword = new ItemStack(Items.NETHERITE_SWORD);
        EnchantHelper.enchant(server, sword, Enchantments.SHARPNESS, 5);
        EnchantHelper.enchant(server, sword, Enchantments.UNBREAKING, 3);
        EnchantHelper.enchant(server, sword, Enchantments.MENDING, 1);
        EnchantHelper.enchant(server, sword, Enchantments.FIRE_ASPECT, 2);
        EnchantHelper.enchant(server, sword, Enchantments.LOOTING, 3);
        EnchantHelper.enchant(server, sword, Enchantments.SWEEPING_EDGE, 3);
        EnchantHelper.unbreakable(sword);
        out.add(sword);

        addToolSet(server, out, Items.NETHERITE_PICKAXE, Items.NETHERITE_AXE,
                Items.NETHERITE_SHOVEL, Items.NETHERITE_HOE, Enchantments.EFFICIENCY, 5);

        ItemStack mace = new ItemStack(Items.MACE);
        EnchantHelper.enchant(server, mace, Enchantments.DENSITY, 5);
        EnchantHelper.enchant(server, mace, Enchantments.WIND_BURST, 3);
        EnchantHelper.unbreakable(mace);
        out.add(mace);

        ItemStack bow = new ItemStack(Items.BOW);
        EnchantHelper.enchant(server, bow, Enchantments.POWER, 5);
        EnchantHelper.enchant(server, bow, Enchantments.FLAME, 1);
        EnchantHelper.enchant(server, bow, Enchantments.INFINITY, 1);
        EnchantHelper.unbreakable(bow);
        out.add(bow);
        out.add(new ItemStack(Items.ARROW, 64));

        out.add(new ItemStack(Items.ELYTRA));
        out.add(new ItemStack(Items.BEACON, 4));
        out.add(new ItemStack(Items.NETHER_STAR, 8));
        out.add(new ItemStack(Items.TOTEM_OF_UNDYING, 4));
        out.add(new ItemStack(Items.ENCHANTED_GOLDEN_APPLE, 16));
        out.add(new ItemStack(Items.NETHERITE_INGOT, 64));
        out.add(new ItemStack(Items.DIAMOND, 64));
        out.add(new ItemStack(Items.COMMAND_BLOCK, 8));
        out.add(new ItemStack(Items.END_CRYSTAL, 16));

        addFood(out, 64);
    }

    // ---------------------------------------------------------------
    // Helpers
    // ---------------------------------------------------------------

    private static void addArmorSet(MinecraftServer server, List<ItemStack> out, Item helmet, Item chest,
                                     Item legs, Item boots,
                                     net.minecraft.registry.RegistryKey<net.minecraft.enchantment.Enchantment> ench,
                                     int level) {
        for (Item piece : new Item[]{helmet, chest, legs, boots}) {
            ItemStack stack = new ItemStack(piece);
            EnchantHelper.enchant(server, stack, ench, level);
            out.add(stack);
        }
    }

    private static void addToolSet(MinecraftServer server, List<ItemStack> out, Item pickaxe, Item axe,
                                    Item shovel, Item hoe,
                                    net.minecraft.registry.RegistryKey<net.minecraft.enchantment.Enchantment> ench,
                                    int level) {
        for (Item tool : new Item[]{pickaxe, axe, shovel, hoe}) {
            ItemStack stack = new ItemStack(tool);
            EnchantHelper.enchant(server, stack, ench, level);
            out.add(stack);
        }
    }

    private static ItemStack enchantedBook(MinecraftServer server,
                                            net.minecraft.registry.RegistryKey<net.minecraft.enchantment.Enchantment> ench,
                                            int level) {
        ItemStack book = new ItemStack(Items.ENCHANTED_BOOK);
        EnchantHelper.storeEnchant(server, book, ench, level);
        return book;
    }

    private static void addFood(List<ItemStack> out, int amount) {
        out.add(new ItemStack(Items.COOKED_BEEF, amount));
        out.add(new ItemStack(Items.GOLDEN_APPLE, Math.max(1, amount / 8)));
    }

    private static List<ItemStack> oresList() {
        List<ItemStack> ores = new ArrayList<>();
        ores.add(new ItemStack(Items.DIAMOND, 32));
        ores.add(new ItemStack(Items.NETHERITE_SCRAP, 8));
        ores.add(new ItemStack(Items.ANCIENT_DEBRIS, 8));
        ores.add(new ItemStack(Items.GOLD_INGOT, 32));
        ores.add(new ItemStack(Items.IRON_INGOT, 32));
        ores.add(new ItemStack(Items.EMERALD, 16));
        return ores;
    }

    private static List<ItemStack> scaleStacks(List<ItemStack> base, int multiplier) {
        if (multiplier <= 1) return base;
        List<ItemStack> scaled = new ArrayList<>();
        for (ItemStack stack : base) {
            ItemStack copy = stack.copy();
            int newCount = Math.min(copy.getMaxCount(), copy.getCount() * multiplier);
            copy.setCount(newCount);
            scaled.add(copy);
        }
        return scaled;
    }

    /**
     * Cria um shulker box preenchido com os itens informados (usando o
     * componente de container do Minecraft 1.21, sem precisar abrir o baú).
     */
    private static ItemStack shulkerWith(List<ItemStack> contents) {
        ItemStack shulker = new ItemStack(Items.SHULKER_BOX);
        shulker.set(DataComponentTypes.CONTAINER, ContainerComponent.fromStacks(contents));
        return shulker;
    }
}
