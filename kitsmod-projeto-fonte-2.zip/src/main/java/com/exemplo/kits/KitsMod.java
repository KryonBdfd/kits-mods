package com.exemplo.kits;

import com.exemplo.kits.command.AddRankCommand;
import com.exemplo.kits.command.KitCommand;
import com.exemplo.kits.command.KitsCommand;
import com.exemplo.kits.command.RemoveRankCommand;
import com.exemplo.kits.cooldown.CooldownManager;
import com.exemplo.kits.rank.RankManager;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.server.MinecraftServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.file.Path;

public class KitsMod implements ModInitializer {

    public static final String MOD_ID = "kitsmod";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    // Instâncias globais, acessadas pelos comandos e pela GUI.
    // São (re)inicializadas quando o servidor sobe, apontando para
    // config/kitsmod/ dentro da pasta do servidor.
    public static RankManager RANKS;
    public static CooldownManager COOLDOWNS;

    private int tickCounter = 0;

    @Override
    public void onInitialize() {
        LOGGER.info("[kitsmod] Inicializando mod de Kits & Ranks...");

        ServerLifecycleEvents.SERVER_STARTING.register(this::onServerStarting);

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            KitsCommand.register(dispatcher);
            KitCommand.register(dispatcher);
            AddRankCommand.register(dispatcher);
            RemoveRankCommand.register(dispatcher);
        });

        // A cada segundo (20 ticks), verifica ranks expirados
        ServerTickEvents.END_SERVER_TICK.register(this::onServerTick);

        LOGGER.info("[kitsmod] Comandos registrados: /kits, /kit, /addrank, /removerank");
    }

    private void onServerStarting(MinecraftServer server) {
        Path configDir = FabricLoader.getInstance().getConfigDir().resolve(MOD_ID);
        RANKS = new RankManager(configDir);
        COOLDOWNS = new CooldownManager(configDir);
        LOGGER.info("[kitsmod] Dados carregados de {}", configDir);
    }

    private void onServerTick(MinecraftServer server) {
        tickCounter++;
        if (tickCounter >= 20) { // 1x por segundo
            tickCounter = 0;
            if (RANKS != null) {
                RANKS.tickExpirations(server);
            }
        }
    }
}
