# Kits & Ranks — Mod Fabric para Minecraft

Mod completo para servidores **Fabric** (compatível com Aternos) que adiciona:

- `/kits` — menu em formato de baú com os kits disponíveis
- `/kit <nome>` — resgata um kit diretamente
- `/addrank <jogador> <rank> <tempo>` — concede um rank temporário (OP nível 4)
- `/removerank <jogador> <rank>` — remove um rank (OP nível 4)
- Cooldown de 5 dias por kit, por jogador
- Persistência total em JSON (`config/kitsmod/ranks.json` e `config/kitsmod/cooldowns.json`)

## Versões usadas neste projeto

| Componente        | Versão               |
|--------------------|----------------------|
| Minecraft          | 1.21.1               |
| Fabric Loader      | 0.16.9                |
| Fabric API         | 0.102.0+1.21.1        |
| Yarn mappings      | 1.21.1+build.3        |
| Java               | 21                     |

> ⚠️ **Importante:** você pediu para eu preencher "a versão exata do seu servidor" —
> como não tenho acesso ao painel do seu Aternos, usei a **1.21.1**, que é uma das
> versões mais comuns e estáveis para Fabric hoje. Se o seu servidor estiver em
> outra versão (ex: 1.21.4, 1.20.1 etc.), troque os valores em `gradle.properties`
> (`minecraft_version`, `yarn_mappings`, `fabric_version`) pelos valores
> correspondentes listados em https://fabricmc.net/develop/ — o restante do
> código tende a precisar de pouquíssimos ajustes entre versões 1.21.x, mas pode
> exigir mudanças maiores se for uma versão bem mais antiga (ex: 1.19 ou 1.18),
> pois a API de "componentes de item" usada aqui (encantamentos, unbreakable,
> conteúdo de shulker box) é específica do sistema introduzido na 1.20.5+.

## ⚠️ Sobre o arquivo .jar

Este ambiente de geração de código **não tem acesso à internet**, e compilar um
mod Fabric exige baixar o Minecraft, os mappings Yarn e a Fabric API via Gradle
na primeira build. Por isso **não foi possível gerar o `.jar` aqui** — mas todo
o projeto está 100% completo, sem pseudocódigo, pronto para compilar assim que
você rodar o build na sua própria máquina (isso leva poucos minutos).

### Como compilar (Windows/Linux/Mac, com Java 21 instalado)

1. Instale o **JDK 21** (obrigatório para Minecraft 1.21.x).
2. Instale o **Gradle 8.8+** (ou use o wrapper — veja abaixo).
3. Abra um terminal na pasta do projeto (`kits-rank-mod/`).
4. Rode:
   ```bash
   gradle wrapper --gradle-version 8.8
   ./gradlew build        # Linux/Mac
   gradlew.bat build      # Windows
   ```
   (O primeiro comando gera os scripts `gradlew`/`gradlew.bat` e o
   `gradle-wrapper.jar`, que não podem ser gerados sem internet neste ambiente.
   Se você já tem Gradle instalado globalmente, pode pular direto para
   `gradle build`.)
5. O `.jar` final aparecerá em `build/libs/kitsmod-1.0.0.jar`.

### Instalação no servidor (Aternos)

1. No painel do Aternos, mude o tipo do servidor para **Fabric** na versão
   escolhida (1.21.1 neste projeto).
2. Envie **também** o `.jar` da **Fabric API** (baixe em
   https://modrinth.com/mod/fabric-api na mesma versão) para a pasta `mods/`.
3. Envie o `kitsmod-1.0.0.jar` gerado para a pasta `mods/` do servidor.
4. Reinicie o servidor.

### Compatibilidade com o cliente (MJ Launcher)

Este mod roda a maior parte da lógica **apenas no servidor** (comandos, kits,
ranks, cooldowns). A GUI do `/kits` usa um baú padrão do jogo, então
**funciona em qualquer cliente vanilla-compatível com Fabric**, inclusive
lançado pelo MJ Launcher — só é necessário que o cliente também tenha o
**Fabric Loader + Fabric API** instalados na mesma versão do servidor (padrão
para qualquer servidor Fabric moddado). Como o mod é declarado com
`"environment": "*"` no `fabric.mod.json`, ele é aceito tanto client-side
quanto server-side, mas não requer nenhuma tela customizada no cliente.

## Como usar

### Jogadores
- `/kits` — abre o menu (baú) com os kits.
- `/kit vip`, `/kit vipplus`, `/kit pro`, `/kit sslayers`, `/kit sslayersplus` —
  resgata o kit correspondente (exige possuir o rank ativo e não estar em
  cooldown).
- `/kit admin` — apenas jogadores com permissão OP nível 4.

### Administradores (OP nível 4)
```
/addrank Steve vip 30d
/addrank Alex pro 7d
/addrank Fulano sslayers 12h
/addrank Ciclano vipplus 45m
/addrank Beltrano pro perm       # rank permanente
/removerank Steve vip
```

Sufixos aceitos em `<tempo>`: `m` (minutos), `h` (horas), `d` (dias). Também
aceita `perm`/`permanente` para um rank sem expiração.

## Estrutura do projeto

```
kits-rank-mod/
├── build.gradle
├── gradle.properties
├── settings.gradle
├── LICENSE
├── src/main/resources/fabric.mod.json
└── src/main/java/com/exemplo/kits/
    ├── KitsMod.java                  (inicializador do mod)
    ├── command/
    │   ├── KitsCommand.java          (/kits)
    │   ├── KitCommand.java           (/kit <nome>)
    │   ├── AddRankCommand.java       (/addrank)
    │   └── RemoveRankCommand.java    (/removerank)
    ├── rank/
    │   ├── RankEntry.java
    │   └── RankManager.java          (persistência + expiração automática)
    ├── cooldown/
    │   └── CooldownManager.java      (persistência + cooldown de 5 dias)
    ├── kit/
    │   ├── KitType.java
    │   ├── KitManager.java           (monta os itens de cada kit)
    │   └── KitService.java           (regras: permissão + cooldown + entrega)
    ├── gui/
    │   ├── KitMenuScreenHandler.java (menu em formato de baú)
    │   ├── KitMenuOpener.java
    │   └── LockedSlot.java
    └── util/
        ├── TimeParser.java           (parser de "30d", "12h", "45m")
        └── EnchantHelper.java        (encantamentos via componentes 1.21)
```

## Observações de design

- Os arquivos JSON de ranks/cooldowns ficam em `config/kitsmod/` dentro da
  pasta do servidor e são salvos a cada alteração — nada se perde ao reiniciar.
- Um "watcher" roda a cada segundo (`ServerTickEvents.END_SERVER_TICK`) e
  remove automaticamente ranks expirados, avisando o jogador se ele estiver
  online.
- O menu `/kits` usa um baú de 1 linha (9 slots); o slot do kit **Admin** só
  aparece para jogadores com permissão OP nível 4.
- Jogadores OP nível 4 podem testar qualquer kit no `/kit <nome>` sem precisar
  ter o rank e sem respeitar cooldown (facilita testes no servidor).
